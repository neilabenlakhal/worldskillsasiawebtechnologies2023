Vue.component('element-group', {
    // language=HTML
    template: `
        <div class="elements">
            <slot></slot>
        </div>
    `,
});