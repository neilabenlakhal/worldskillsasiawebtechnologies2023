Vue.component('link-group', {
    // language=HTML
    template: `
        <svg class="links">
            <slot></slot>
        </svg>
    `,
});