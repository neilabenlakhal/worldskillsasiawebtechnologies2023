# Codes of Woldskills 2019 Web Technologies
This is a buldle of codes of Worldskills 2019 Web Technologies.

Please use this files to learn Worldskills Test Projects. 

You can also find some videos about this in Youtube Channel.

https://www.youtube.com/playlist?list=PLD06Ljj3Kz2K9b_qFsNaTxlLm7iMI-rfF

This is not a perfect solution, but We hope it will help you learn.

Worldskills Korea Web Technologies Team. 
