function changeFace(number) {
    const face = document.getElementById('face');
    face.setAttribute('data-face', number);
}